<?php

namespace App\Http\Controllers;

use App\Models\CurrentSalary;
use Illuminate\Http\Request;

class CurrentSalaryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(CurrentSalary $currentSalary)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CurrentSalary $currentSalary)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, CurrentSalary $currentSalary)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CurrentSalary $currentSalary)
    {
        //
    }
}
