<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Create Clients</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Clients</li>
                        <li class="breadcrumb-item active">Create</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <form method="POST" action="<?php echo e(route('clients.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="card card-primary">
                                            <div class="card-header">
                                                <h3 class="card-title">Client Details</h3>
                                            </div>
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-6">
                                                        <div class="form-group">
                                                            <label>Source</label>
                                                            <select class="form-control select2bs4 <?php $__errorArgs = ['source'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="width: 100%;" name="source">
                                                                <option value="" selected>-- SELECT SOURCE --</option>
                                                                <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($source->id); ?>"><?php echo e($source->name); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php $__errorArgs = ['source'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="d-block fs-6 text-danger"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="companyName">Company Name</label>
                                                            <input type="text" class="form-control <?php $__errorArgs = ['companyName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="companyName" id="companyName">
                                                            <?php $__errorArgs = ['companyName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="d-block fs-6 text-danger"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="TA">T/A</label>
                                                            <input type="text" class="form-control" id="TA" name="TA">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="natureBusiness">Nature of Business</label>
                                                            <input type="text" class="form-control" name="natureBusiness" id="natureBusiness">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="specialistArea">Specialist Area</label>
                                                            <input type="text" class="form-control" name="specialistArea" id="specialistArea">
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Industry</label>
                                                            <select class="form-control select2bs4" style="width: 100%;" name="industry">
                                                                <option value="" selected>-- SELECT INDUSTRY --
                                                                </option>
                                                                <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($industry->id); ?>">
                                                                        <?php echo e($industry->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="address">Address</label>
                                                            <input type="text" class="form-control" name="address" id="address">
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Country</label>
                                                            <select class="form-control select2bs4" name="country">
                                                                <option selected value="">-- SELECT REGION --</option>
                                                                <?php $__currentLoopData = $nationalityContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($country['num_code']); ?>">
                                                                        <?php echo e($country['en_short_name']); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Region</label>
                                                            <select class="form-control select2bs4" style="width: 100%;" name="region" id="region">
                                                                <option value="" selected>-- SELECT REGION -- </option>
                                                                <?php $__currentLoopData = $regionContent['RECORDS']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($region['id']); ?>"
                                                                        data-regcode="<?php echo e($region['regCode']); ?>">
                                                                        <?php echo e($region['regDesc']); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Province</label>
                                                            <select class="form-control select2bs4" style="width: 100%;" name="province" id="province">
                                                                <option value="" selected>-- SELECT PROVINCE --</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>City</label>
                                                            <select class="form-control select2bs4" style="width: 100%;" name="city" id="city">
                                                                <option value="" selected>-- SELECT CITY --</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Barangay</label>
                                                            <select class="form-control select2bs4" style="width: 100%;" name="barangay" id="barangay">
                                                                <option value="" selected>-- SELECT BARANGAY --</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="zipCode">Zip Code</label>
                                                            <input type="text" class="form-control" name="zipCode" id="zipCode">
                                                        </div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="form-group">
                                                            <label for="telno">Telephone Number</label>
                                                            <input type="text" class="form-control" name="telno id="telno">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="alternateTelNo">Alternate Telephone Number</label>
                                                            <input type="text" class="form-control" name="alternateTelNo" id="alternateTelNo">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="email">Email</label>
                                                            <input type="email" class="form-control" name="email" id="email">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="website">Website</label>
                                                            <input type="text" class="form-control" name="website" id="website">
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Terms Sent</label>
                                                            <select class="form-control select2bs4" style="width: 100%;" name="termSent">
                                                                <option value="" selected>-- SELECT TERMS SENT --
                                                                </option>
                                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($user->id); ?>">
                                                                        <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Term Sent Date:</label>
                                                            <div class="input-group date" id="termSentDate"
                                                                data-target-input="nearest">
                                                                <input type="text"
                                                                    class="form-control datetimepicker-input"
                                                                    data-target="#termSentDate" name="termSentDate"/>
                                                                <div class="input-group-append"
                                                                    data-target="#termSentDate"
                                                                    data-toggle="datetimepicker">
                                                                    <div class="input-group-text"><i
                                                                            class="fa fa-calendar"></i></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Terms Received</label>
                                                            <select class="form-control select2bs4" style="width: 100%;" name="termReceive">
                                                                <option value="" selected>-- SELECT TERMS RECEIVE --</option>
                                                                <?php $__currentLoopData = $termReceives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $termReceive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($termReceive->id); ?>">
                                                                        <?php echo e($termReceive->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Term Received Date:</label>
                                                            <div class="input-group date" id="termReceivedDate"
                                                                data-target-input="nearest">
                                                                <input type="text"
                                                                    class="form-control datetimepicker-input"
                                                                    data-target="#termReceivedDate" name="termReceivedDate"/>
                                                                <div class="input-group-append"
                                                                    data-target="#termReceivedDate"
                                                                    data-toggle="datetimepicker">
                                                                    <div class="input-group-text"><i
                                                                            class="fa fa-calendar"></i></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card card-primary">
                                            <div class="card-header">
                                                <h3 class="card-title">Contact Details</h3>
                                            </div>
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-6">
                                                        <div class="form-group">
                                                            <label>Salutation</label>
                                                            <select class="form-control select2bs4" style="width: 100%;" name="salutation">
                                                                <option value="" selected>-- SELECT SALUTATION --
                                                                </option>
                                                                <?php $__currentLoopData = $salutations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salutation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($salutation->id); ?>">
                                                                        <?php echo e($salutation->salutations); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="contactFirstName">First Name</label>
                                                            <input type="text" class="form-control" name="contactFirstName"
                                                                id="contactFirstName">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="contactLastName">Last Name</label>
                                                            <input type="text" class="form-control" name="contactLastName"
                                                                id="contactLastName">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="contactPosition">Position</label>
                                                            <input type="text" class="form-control" name="contactPosition"
                                                                id="contactPosition">
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Decision Maker</label>
                                                            <select class="form-control select2bs4" style="width: 100%;" name="decisionMaker">
                                                                <option selected="selected">-- SELECT AN OPTION --</option>
                                                                <option value="1">Yes</option>
                                                                <option value="0">No</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="form-group">
                                                            <label for="contactDirectDial">Direct Dial</label>
                                                            <input type="text" class="form-control" name="contactDirectDial"
                                                                id="contactDirectDial">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="contactMobileNo">Mobile Number</label>
                                                            <input type="text" class="form-control" name="contactMobileNo"
                                                                id="contactMobileNo">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="contactEmail">Email</label>
                                                            <input type="email" class="form-control" name="contactEmail" id="contactEmail">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="notes">Notes</label>
                                                            <textarea class="form-control" name="notes" id="notes"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                <div class="submit-btn text-center">
                                    <a href="/iris/clients"><button type="button"
                                            class="btn btn-default mr-3">Cancel</button></a>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </div>
                        <!-- /.card -->
                    </form>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    
    <script src="<?php echo e(asset('admin/js/clients.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/global.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/dev-i21recruitment.indigo21.com/resources/views/admin/pages/clients/addEdit.blade.php ENDPATH**/ ?>