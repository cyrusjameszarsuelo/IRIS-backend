<!DOCTYPE html>
<html>
<head>
	<?php echo $__env->make('admin/includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed">

	<div class="wrapper">
		<?php echo $__env->make('admin/includes/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->make('admin/includes/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div class="content-wrapper">

			<?php echo $__env->yieldContent('content'); ?>

		</div>

		<footer class="main-footer">
			<strong>Copyright &copy;<?php echo e(date('Y')); ?> <a href="">i21recruitment</a>.</strong>
			All rights reserved.
		</footer>

		<!-- Control Sidebar -->
		<aside class="control-sidebar control-sidebar-dark">
			<!-- Control sidebar content goes here -->
		</aside>
		<!-- /.control-sidebar -->
	</div>
	<?php echo $__env->make('admin/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH /var/www/dev-i21recruitment.indigo21.com/resources/views/admin/main.blade.php ENDPATH**/ ?>